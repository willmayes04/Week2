#Code to format the days of the week

#prodecure to run data and give outputs
def DayFormat(Day,Format):
  DayList = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
  ShortDayList = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
  CharList = ["M","Tu","W","Th","F","Sa","Su"]
  if Format == "day":
    print(DayList[Day-1])
  elif Format == "shortday":
    print(ShortDayList[Day-1])
  elif Format == "char":
    print(CharList[Day-1])

#inputs to test
DayFormat(1,"day")
DayFormat(3,"shortday")
DayFormat(7,"char")