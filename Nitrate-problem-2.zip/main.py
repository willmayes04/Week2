#Code to work out dosage compared to nitrate

#function calculate valus and return them
def NitrateDose(nitrate):
  if nitrate < 10:
    if nitrate < 2.5:
      if nitrate < 1:
        return 0.5
      else:
        return 1
    else:
      return 2
  else:
    return 3

#test inputs
print(NitrateDose(12))
print(NitrateDose(7))
print(NitrateDose(2))
print(NitrateDose(0.3))
