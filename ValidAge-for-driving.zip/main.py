#selection commands

#subroutine to return eligibility to drive
def CheckAge(Age):
  if Age > 17:
    print("You are old enough to learn to drive.")
  else:
    print("You are not old enough to learn to drive.")

# Main Program
CheckAge(14)
CheckAge(16)
CheckAge(17)
CheckAge(18)
CheckAge(20)

#selection commands

#subroutine to return eligibility to drive
def CheckHeight(Height):
  if Height > 103:
    print("You are tall enough to go on the ride")
  else:
    print("You are not tall enough to go on the ride")

# Main Program
CheckHeight(103)