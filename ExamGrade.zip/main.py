

#Procedure to output grade from mark
def ExamGrade(Grade):
  if Grade >= 80 and Grade <= 100 :
    print("You got a grade 9, highest grade.")
  elif Grade >= 67 and Grade < 80 :
    print("You got a grade 8,",80-Grade,"marks away from a grade 9.")
  elif Grade >= 54 and Grade < 67 :
    print("You got a grade 7,",67-Grade,"marks away from a grade 8.")
  elif Grade >= 41 and Grade < 54 :
    print("You got a grade 6,",54-Grade,"marks away from a grade 7.")
  elif Grade >= 31 and Grade < 41 :
    print("You got a grade 5,",41-Grade,"marks away from a grade 6.")
  elif Grade >= 22 and Grade < 31 :
    print("You got a grade 4,",31-Grade,"marks away from a grade 5.")
  elif Grade >= 13 and Grade < 22 :
    print("You got a grade 3,",22-Grade,"marks away from a grade 4.")
  elif Grade >= 4 and Grade < 13 :
    print("You got a grade 2,",13-Grade,"marks away from a grade 3.")
  elif Grade >= 2 and Grade < 4 :
    print("You got a grade 1,",4-Grade,"marks away from a grade 2.")
  elif Grade >= 0 and Grade < 2 :
    print("You got a grade U,",2-Grade,"marks away from a grade 1.")
  else:
    print("Grade not recognised.")

ExamGrade(101)
ExamGrade(100)
ExamGrade(54)
ExamGrade(37)
ExamGrade(3)
ExamGrade(1)
ExamGrade(-3)
