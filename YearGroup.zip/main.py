#selection commands

#subroutine to return eligibility to drive
def YearGroup(Year):
  if Year >= 7 and Year < 10 :
    print("Key Stage 3")
  elif Year >= 10 and Year < 12 :
    print("Key Stage 4")

# Main Program
YearGroup(10)
YearGroup(7)
YearGroup(11)
YearGroup(6)
YearGroup(13)