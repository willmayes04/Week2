# Selection commands

# Subroutine to validate month
def ValidMonth(Month):
  if Month > 0 and Month < 13:
    print("Valid month.")
  else:
    print("Invalid month.")
  
#Main program
ValidMonth(13)

# Selection commands

# Subroutine to validate age
def ValidAge(Age):
  if Age > 1 and Age < 6:
    print("Valid Age.")
  else:
    print("Invalid Age.")
  
#Main program
ValidAge(-5)
ValidAge(0)
ValidAge(1)
ValidAge(2)
ValidAge(3)
ValidAge(5)
ValidAge(7)