#Code to convert currency 

#Procedure to convert the Currency
#Also formats it to 2dp
def CurrencyConverter(ValueGBP,Currency):
  if Currency == "dollar":
    print("In USD is",round(ValueGBP * 1.31,2))
  elif Currency == "euro":
    print("In euros is",round(ValueGBP * 1.11,2))
  elif Currency == "yaun":
    print("In Yuan is",round(ValueGBP * 8.65,2))
  elif Currency == "yen":
    print("In Yen is",round(ValueGBP * 136.26,2))

#test inputs
CurrencyConverter(28.50,"dollar")
CurrencyConverter(745.87,"euro")
CurrencyConverter(56.42,"yaun")
CurrencyConverter(5064.23,"yen")